import{createRequire as ___cr}from'module';import{fileURLToPath as ___f}from'url';import{dirname as ___d}from'path';const require=___cr(import.meta.url);const __filename=___f(import.meta.url);const __dirname=___d(__filename);

// index.ts
var index_default = {
  fetch: (_) => {
    const body = JSON.stringify({ FOO: process.env.FOO, BAR: process.env.BAR });
    return new Response(body, {
      headers: { "content-type": "application/json" }
    });
  }
};
export {
  index_default as default
};
